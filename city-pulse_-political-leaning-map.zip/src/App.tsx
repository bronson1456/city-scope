import { useState, useEffect, useCallback } from 'react';
import Map from './components/Map.tsx';
import { getCityPoliticalLeaning, CityLeaning } from './services/geminiService.ts';
import { Search, MapPin, Info, AlertCircle, Loader2, ExternalLink, X, ChevronRight, ChevronLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface MarkerData {
  lat: number;
  lng: number;
  city: string;
  country: string;
  leaning: string;
  data: CityLeaning;
}

export default function App() {
  const [markers, setMarkers] = useState<MarkerData[]>([]);
  const [selectedCity, setSelectedCity] = useState<MarkerData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const handleCityClick = useCallback(async (lat: number, lng: number) => {
    setIsLoading(true);
    setError(null);
    try {
      // Reverse geocoding using Nominatim (OpenStreetMap)
      const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=10`);
      const data = await response.json();
      
      const city = data.address.city || data.address.town || data.address.village || data.address.suburb || data.address.county;
      const country = data.address.country;

      if (!city) {
        throw new Error("Could not identify a city at this location.");
      }

      const politicalData = await getCityPoliticalLeaning(city, country);
      
      const newMarker: MarkerData = {
        lat,
        lng,
        city,
        country,
        leaning: politicalData.leaning,
        data: politicalData
      };

      setMarkers(prev => [...prev, newMarker]);
      setSelectedCity(newMarker);
      setIsSidebarOpen(true);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : "An unexpected error occurred.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}&limit=1`);
      const data = await response.json();

      if (data.length === 0) {
        throw new Error("City not found.");
      }

      const { lat, lon, display_name } = data[0];
      const latNum = parseFloat(lat);
      const lngNum = parseFloat(lon);

      // Extract city and country from display_name or address
      const addressParts = display_name.split(', ');
      const city = addressParts[0];
      const country = addressParts[addressParts.length - 1];

      const politicalData = await getCityPoliticalLeaning(city, country);

      const newMarker: MarkerData = {
        lat: latNum,
        lng: lngNum,
        city,
        country,
        leaning: politicalData.leaning,
        data: politicalData
      };

      setMarkers(prev => [...prev, newMarker]);
      setSelectedCity(newMarker);
      setIsSidebarOpen(true);
      setSearchQuery('');
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : "An unexpected error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-gray-50 font-sans">
      {/* Header */}
      <header className="absolute top-4 left-4 right-4 z-10 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-3 bg-white/90 backdrop-blur-md px-4 py-2 rounded-2xl shadow-xl border border-gray-100 pointer-events-auto">
          <div className="bg-indigo-600 p-2 rounded-xl">
            <MapPin className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-gray-900 leading-none">City Pulse</h1>
            <p className="text-[10px] font-medium text-gray-500 uppercase tracking-wider">Political Leaning Map</p>
          </div>
        </div>

        <form onSubmit={handleSearch} className="flex-1 max-w-md mx-4 pointer-events-auto">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-indigo-500 transition-colors" />
            <input
              type="text"
              placeholder="Search for a city..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white/90 backdrop-blur-md rounded-2xl shadow-xl border border-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-gray-700"
            />
          </div>
        </form>

        <div className="hidden md:flex items-center gap-2 bg-white/90 backdrop-blur-md px-4 py-2 rounded-2xl shadow-xl border border-gray-100 pointer-events-auto">
          <Info className="w-4 h-4 text-gray-400" />
          <span className="text-xs font-medium text-gray-600">Click map to analyze</span>
        </div>
      </header>

      {/* Main Map */}
      <main className="h-full w-full">
        <Map onCityClick={handleCityClick} markers={markers} />
      </main>

      {/* Sidebar / Detail Panel */}
      <AnimatePresence>
        {isSidebarOpen && selectedCity && (
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="absolute top-0 right-0 h-full w-full md:w-[400px] bg-white shadow-2xl z-20 flex flex-col border-l border-gray-100"
          >
            <div className="p-6 flex items-center justify-between border-bottom border-gray-100">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "p-2 rounded-xl",
                  selectedCity.leaning === 'liberal' ? "bg-blue-50 text-blue-600" :
                  selectedCity.leaning === 'conservative' ? "bg-red-50 text-red-600" :
                  "bg-gray-50 text-gray-600"
                )}>
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">{selectedCity.city}</h2>
                  <p className="text-sm text-gray-500">{selectedCity.country}</p>
                </div>
              </div>
              <button 
                onClick={() => setIsSidebarOpen(false)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-8">
              {/* Leaning Indicator */}
              <div className="space-y-3">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Political Leaning</label>
                <div className={cn(
                  "px-4 py-3 rounded-2xl flex items-center justify-between",
                  selectedCity.leaning === 'liberal' ? "bg-blue-600 text-white" :
                  selectedCity.leaning === 'conservative' ? "bg-red-600 text-white" :
                  "bg-gray-800 text-white"
                )}>
                  <span className="text-lg font-bold capitalize">{selectedCity.leaning}</span>
                  <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
                </div>
              </div>

              {/* Explanation */}
              <div className="space-y-3">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Analysis & Context</label>
                <div className="prose prose-sm prose-indigo text-gray-600 leading-relaxed">
                  <ReactMarkdown>{selectedCity.data.explanation}</ReactMarkdown>
                </div>
              </div>

              {/* Sources */}
              <div className="space-y-3">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Real Data Sources</label>
                <div className="space-y-2">
                  {selectedCity.data.sources.map((source, idx) => (
                    <a
                      key={idx}
                      href={source.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-between p-3 bg-gray-50 hover:bg-indigo-50 rounded-xl group transition-all border border-transparent hover:border-indigo-100"
                    >
                      <span className="text-sm font-medium text-gray-700 group-hover:text-indigo-700 truncate mr-2">
                        {source.title}
                      </span>
                      <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-indigo-500 flex-shrink-0" />
                    </a>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-6 bg-gray-50 border-t border-gray-100">
              <p className="text-[10px] text-gray-400 text-center italic">
                Data generated using AI analysis of real-world voting patterns and demographic trends. No Wikipedia data used.
              </p>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Loading Overlay */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-white/60 backdrop-blur-sm"
          >
            <div className="bg-white p-8 rounded-3xl shadow-2xl border border-gray-100 flex flex-col items-center gap-4">
              <div className="relative">
                <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-2 h-2 bg-indigo-600 rounded-full animate-ping" />
                </div>
              </div>
              <div className="text-center">
                <p className="text-lg font-bold text-gray-900">Analyzing City Data</p>
                <p className="text-sm text-gray-500">Fetching real-time political insights...</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Error Toast */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2 z-50"
          >
            <div className="bg-red-600 text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">{error}</span>
              <button onClick={() => setError(null)} className="ml-2 hover:bg-white/20 p-1 rounded-lg transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sidebar Toggle (Mobile) */}
      {!isSidebarOpen && selectedCity && (
        <button
          onClick={() => setIsSidebarOpen(true)}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-white p-3 rounded-full shadow-xl border border-gray-100 hover:bg-indigo-50 text-indigo-600 transition-all"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
      )}
    </div>
  );
}
