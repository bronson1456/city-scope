import { MapContainer, TileLayer, Marker, Popup, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L, { LatLngExpression } from 'leaflet';

// Fix for default marker icons in React-Leaflet using CDN
const DefaultIcon = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

interface MapProps {
  onCityClick: (lat: number, lng: number) => void;
  markers: { lat: number; lng: number; city: string; leaning: string }[];
}

function MapEvents({ onCityClick }: { onCityClick: (lat: number, lng: number) => void }) {
  useMapEvents({
    click(e) {
      onCityClick(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
}

export default function Map({ onCityClick, markers }: MapProps) {
  const center: LatLngExpression = [39.8283, -98.5795]; // Center of US

  return (
    <MapContainer
      center={center}
      zoom={4}
      style={{ height: '100%', width: '100%' }}
      className="z-0"
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <MapEvents onCityClick={onCityClick} />
      {markers.map((marker, idx) => (
        <Marker key={idx} position={[marker.lat, marker.lng] as LatLngExpression}>
          <Popup>
            <div className="p-2">
              <h3 className="font-bold text-lg">{marker.city}</h3>
              <p className={`text-sm font-semibold ${
                marker.leaning === 'liberal' ? 'text-blue-600' :
                marker.leaning === 'conservative' ? 'text-red-600' :
                'text-gray-600'
              }`}>
                {marker.leaning.charAt(0).toUpperCase() + marker.leaning.slice(1)}
              </p>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
