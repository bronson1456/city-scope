import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface CityLeaning {
  city: string;
  country: string;
  leaning: "liberal" | "conservative" | "neutral" | "mixed";
  explanation: string;
  sources: { title: string; url: string }[];
}

export async function getCityPoliticalLeaning(cityName: string, countryName: string): Promise<CityLeaning> {
  const prompt = `Determine the political leaning (liberal, conservative, neutral, or mixed) of the city of ${cityName}, ${countryName}. 
  Provide a brief explanation based on recent data (e.g., voting records, local government policies, or demographic trends). 
  DO NOT USE WIKIPEDIA. 
  Return the result in JSON format with the following fields: 
  - city: string
  - country: string
  - leaning: "liberal" | "conservative" | "neutral" | "mixed"
  - explanation: string
  - sources: array of { title: string, url: string }`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          city: { type: Type.STRING },
          country: { type: Type.STRING },
          leaning: { type: Type.STRING, enum: ["liberal", "conservative", "neutral", "mixed"] },
          explanation: { type: Type.STRING },
          sources: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                url: { type: Type.STRING }
              },
              required: ["title", "url"]
            }
          }
        },
        required: ["city", "country", "leaning", "explanation", "sources"]
      }
    }
  });

  try {
    const data = JSON.parse(response.text || "{}");
    return data as CityLeaning;
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    throw new Error("Failed to get political leaning data.");
  }
}
